import Image from "next/image";
import styles from "./style.module.css";

// Add your props inside the ()
const TripCard = () => {
  //Code here
};

export default TripCard;