import styles from "./style.module.css";

// Add your props inside the ()
const ActivityCard = () => {
    // Code here
    {/* Bonus: express rating as stars using a cool trick with star emojis using fill and join string operations
          Array(Number(rating)).fill('⭐').join('') */}
};

export default ActivityCard;